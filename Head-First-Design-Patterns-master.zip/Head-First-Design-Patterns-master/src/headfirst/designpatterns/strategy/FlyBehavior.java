package headfirst.designpatterns.strategy;

public interface FlyBehavior {
	public void fly();
}
