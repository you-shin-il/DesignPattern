package headfirst.designpatterns.adapter.ducks;

public interface Turkey {
	public void gobble();
	public void fly();
}
