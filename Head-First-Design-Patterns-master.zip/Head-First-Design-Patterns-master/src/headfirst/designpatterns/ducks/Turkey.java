package headfirst.designpatterns.ducks;

public interface Turkey {
	public void gobble();
	public void fly();
}
