package headfirst.designpatterns.command.remote;

public interface Command {
	public void execute();
}
