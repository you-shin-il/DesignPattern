package headfirst.designpatterns.observer.weather;

public interface DisplayElement {
	public void display();
}
